ALEXA AI — Android starter project (v1.0)

इस ZIP में Android Studio project और app का UI/source code है।

शामिल:
- Chat interface और local chat history
- Voice input interface (डिवाइस/WebView speech recognition पर निर्भर)
- Image upload और preview
- Web search (browser में Google search खोलता है)
- Content creator और coding helper request screens
- Hindi/English preference, dark/light theme
- AI backend URL setting

ज़रूरी सीमा:
यह अभी starter/demo build है, पूरा live AI product नहीं। Live AI chat, image understanding और image generation के लिए सुरक्षित server/backend और model API जोड़ना होगा। API secret को APK में न रखें। Search वास्तविक browser search खोलता है। Alexa नाम Amazon के Alexa brand से जुड़ा है; सार्वजनिक रिलीज़ से पहले नाम/trademark की जाँच करें।

APK बनाने के लिए:
1. Android Studio में इस folder को Open करें।
2. Gradle sync पूरा होने दें (इंटरनेट और Android SDK Platform 35 चाहिए)।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK app/build/outputs/apk/debug/app-debug.apk में बनेगा।

Package: com.alexaai.assistant
